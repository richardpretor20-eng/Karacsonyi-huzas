import { getStore } from "@netlify/blobs";
import { scryptSync, timingSafeEqual } from "node:crypto";

const PEOPLE = ["Gaga", "Zsófi", "Judit", "Ricsi", "Ancsi", "Hedi", "Viki", "Lili"];
const KEYS = ["gaga", "zsofi", "judit", "ricsi", "ancsi", "hedi", "viki", "lili"];
const PIN_DATA = {"gaga": {"salt": "28bc91c4ddbb08fbdc5ac6a56eed39de", "hash": "a056a2dee2f88f853949728b12abb76b4f63418377c77b595c7b2aed5333384f"}, "zsofi": {"salt": "9a405986dbed7d47f7300cf977b2716e", "hash": "ae3cc6d8fe4b5dcc5f9c916801f04bc9e0b0029a69a60eefff9b7806392d8051"}, "judit": {"salt": "d999c803cbb957926c37e5653a2c804c", "hash": "af895a8990a2caa7d240898a1826789040cb37d035fbe2351725bce5e786f2d1"}, "ricsi": {"salt": "6d4074a02532da626dacb8625102a82a", "hash": "5042f754cc313720eff1aeabac1e27c6f5cde608591ea193f83d5ae6a8108ce2"}, "ancsi": {"salt": "0ca750ff31005e9be97ea94c80b37c0f", "hash": "833e5119c0df0a6835950672b76005da7c22b0b73be59f56ffee8a1a60530c7e"}, "hedi": {"salt": "5db2abd32858c62b2daee86e7a9734f2", "hash": "1ce2ad535383800f23b4b0d8babfafc0dc88a8b053ec7c071ce573b766dcc2d0"}, "viki": {"salt": "3ecb099b7f718b078afdd13bf1e3fd1d", "hash": "fa6f3e013b0b67a4d1d130f2a690e09a335fe9f2d9765a8ec3498a7f3d682d04"}, "lili": {"salt": "2831fabf09a510757472c675bfb09a8a", "hash": "9113e04e0a9b00f4e1367de3d1b5104365b0a6464f3d515d813ab6242bacc26d"}};
const RECIPIENT = {"gaga": "ricsi", "zsofi": "viki", "judit": "lili", "ricsi": "hedi", "ancsi": "gaga", "hedi": "judit", "viki": "zsofi", "lili": "ancsi"};

const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }
});

function validPin(key, pin) {
  const item = PIN_DATA[key];
  if (!item || typeof pin !== "string" || !/^\\d{6}$/.test(pin)) return false;
  const actual = scryptSync(pin, Buffer.from(item.salt, "hex"), 32);
  const expected = Buffer.from(item.hash, "hex");
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

export default async (req) => {
  try {
    const store = getStore("karacsonyi-huzas-2026-lili");
    if (req.method === "GET") {
      const records = await Promise.all(KEYS.map(async key => [key, await store.get(`drawn:${key}`, { consistency: "strong" })]));
      const drawn = Object.fromEntries(records.filter(([, value]) => value !== null));
      const remainingGivers = KEYS.filter(key => !(key in drawn));
      const usedRecipients = Object.values(drawn);
      const remainingRecipients = KEYS.filter(key => !usedRecipients.includes(key));
      return json({
        remainingGivers: remainingGivers.map(key => PEOPLE[KEYS.indexOf(key)]),
        remainingRecipients: remainingRecipients.map(key => PEOPLE[KEYS.indexOf(key)]),
        completed: remainingGivers.length === 0
      });
    }
    if (req.method !== "POST") return json({ error: "Nem támogatott kérés." }, 405);
    const body = await req.json();
    const key = body?.name;
    const pin = body?.pin;
    if (!KEYS.includes(key) || !validPin(key, pin)) return json({ error: "Hibás név vagy belépőkód." }, 401);
    const existing = await store.get(`drawn:${key}`, { consistency: "strong" });
    if (existing !== null) return json({ error: "Ezzel a névvel már megtörtént a húzás." }, 409);
    const recipient = RECIPIENT[key];
    const result = await store.set(`drawn:${key}`, recipient, { onlyIfNew: true });
    if (!result.modified) return json({ error: "Ezzel a névvel már megtörtént a húzás." }, 409);
    return json({ recipient: PEOPLE[KEYS.indexOf(recipient)] });
  } catch (error) {
    return json({ error: "A húzás most nem sikerült. Próbáld újra pár másodperc múlva." }, 500);
  }
};
